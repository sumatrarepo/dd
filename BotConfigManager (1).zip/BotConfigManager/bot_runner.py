import threading
import logging
from datetime import datetime
import time
from app import db
from models import BotConfig, ChannelConfig
import discord_bot

# Dictionary to keep track of running bots
running_bots = {}

class BotThread(threading.Thread):
    def __init__(self, bot_config_id):
        super().__init__()
        self.bot_config_id = bot_config_id
        self.stop_event = threading.Event()
        self.daemon = True  # Make thread a daemon so it exits when main thread exits
    
    def run(self):
        try:
            logging.info(f"Starting bot with ID {self.bot_config_id}")
            
            # Get the latest configuration from the database
            from app import app
            with app.app_context():
                bot_config = BotConfig.query.get(self.bot_config_id)
                if not bot_config:
                    logging.error(f"Bot config {self.bot_config_id} not found")
                    return
                
                # Convert database model to dictionary format expected by discord_bot
                token_info = {
                    "bot_config_id": self.bot_config_id,  # Add bot_config_id to token_info
                    "token": bot_config.token,
                    "user_id": bot_config.user_id,
                    "duration": bot_config.duration,
                    "webhook_url": bot_config.webhook_url,
                    "channels": []
                }
                
                for channel in bot_config.channels:
                    # Pastikan delay_min dan delay_max dikonversi ke int
                    try:
                        delay_min = int(channel.delay_min)
                        delay_max = int(channel.delay_max)
                    except (ValueError, TypeError) as e:
                        logging.error(f"Error converting delay values for channel {channel.id}: {str(e)}")
                        delay_min = 3600  # Default 1 jam
                        delay_max = 7200  # Default 2 jam
                        
                    channel_info = {
                        "channel_id": channel.channel_id,
                        "delay_range": (delay_min, delay_max),
                        "message_content": channel.message_content,
                        "channel_config_id": channel.id  # Add channel_config_id for history tracking
                    }
                    token_info["channels"].append(channel_info)
            
            # Start the bot with the configuration
            bot_thread = threading.Thread(
                target=discord_bot.send_message_with_delay, 
                args=(token_info,)
            )
            bot_thread.daemon = True
            bot_thread.start()
            
            # Monitor the stop event
            while not self.stop_event.is_set():
                time.sleep(1)
            
            logging.info(f"Bot with ID {self.bot_config_id} stopped")
            
        except Exception as e:
            logging.error(f"Error in bot thread for ID {self.bot_config_id}: {str(e)}")
            # Update the database to mark bot as stopped due to error
            from app import app  # Memindahkan import ke sini untuk menghindari unbound error
            with app.app_context():
                bot_config = BotConfig.query.get(self.bot_config_id)
                if bot_config:
                    bot_config.is_running = False
                    db.session.commit()

def start_bot(bot_config_id):
    """Start a bot with the given configuration ID"""
    # Check if the bot is already running
    if bot_config_id in running_bots:
        logging.warning(f"Bot with ID {bot_config_id} is already running")
        return False
    
    try:
        # Get channel count for validation
        from app import app
        with app.app_context():
            bot_config = BotConfig.query.get(bot_config_id)
            if not bot_config:
                logging.error(f"Bot config {bot_config_id} not found")
                return False
                
            channel_count = len(bot_config.channels)
            logging.info(f"Starting bot with ID {bot_config_id} with {channel_count} channels")
            
            if channel_count == 0:
                logging.error(f"No channels configured for bot ID {bot_config_id}")
                return False
        
        # Create and start a new bot thread
        bot_thread = BotThread(bot_config_id)
        bot_thread.start()
        
        # Store the thread reference
        running_bots[bot_config_id] = bot_thread
        logging.info(f"Bot with ID {bot_config_id} started successfully")
        return True
    except Exception as e:
        logging.error(f"Failed to start bot with ID {bot_config_id}: {str(e)}")
        return False

def stop_bot(bot_config_id):
    """Stop a running bot"""
    if bot_config_id not in running_bots:
        logging.warning(f"Bot with ID {bot_config_id} is not running")
        
        # Jika tidak ada di running_bots, periksa masih ada di database dgn status running
        from app import app
        with app.app_context():
            bot_config = BotConfig.query.get(bot_config_id)
            if bot_config and bot_config.is_running:
                # Force stop melalui flag
                import discord_bot
                discord_bot.stop_all_flag.set()
                logging.info(f"Force stopping bot ID {bot_config_id} via global flag")
                
                # Update database
                bot_config.is_running = False
                db.session.commit()
                logging.info(f"Updated database status for bot ID {bot_config_id} to stopped")
                
                # Reset flag after a delay
                def reset_stop_flag():
                    time.sleep(10)  # Berikan waktu lebih lama
                    discord_bot.stop_all_flag.clear()
                    logging.info("Reset global stop flag")
                
                reset_thread = threading.Thread(target=reset_stop_flag)
                reset_thread.daemon = True
                reset_thread.start()
                
                return True
        
        return False
    
    try:
        # Signal the bot thread to stop
        running_bots[bot_config_id].stop_event.set()
        
        # Set the global stop flag in discord_bot to stop all channels
        import discord_bot
        discord_bot.stop_all_flag.set()
        logging.info("Set global stop flag to stop all channel threads")
        
        # Update database status
        from app import app
        with app.app_context():
            bot_config = BotConfig.query.get(bot_config_id)
            if bot_config:
                bot_config.is_running = False
                db.session.commit()
                logging.info(f"Updated database status for bot ID {bot_config_id} to stopped")
        
        # Force kill semua thread yang terkait dengan bot ini
        if bot_config_id in discord_bot.active_threads:
            thread_list = discord_bot.active_threads[bot_config_id]
            logging.info(f"Found {len(thread_list)} active threads for bot {bot_config_id}")
            # Python tidak mendukung forced thread termination, jadi kita hanya bisa mengandalkan stop_flag
        
        # Remove from the running bots dictionary
        del running_bots[bot_config_id]
        logging.info(f"Bot with ID {bot_config_id} stopped successfully")
        
        # Reset the stop flag after a longer delay (to ensure all threads have a chance to check it)
        def reset_stop_flag():
            time.sleep(10)  # Berikan waktu lebih lama (10 detik) untuk thread melihat flag dan exit
            discord_bot.stop_all_flag.clear()
            logging.info("Reset global stop flag")
        
        # Start a thread to reset the flag after a delay
        reset_thread = threading.Thread(target=reset_stop_flag)
        reset_thread.daemon = True
        reset_thread.start()
        
        return True
    except Exception as e:
        logging.error(f"Failed to stop bot with ID {bot_config_id}: {str(e)}")
        return False

def get_running_bot_ids():
    """Get a list of currently running bot IDs"""
    return list(running_bots.keys())
