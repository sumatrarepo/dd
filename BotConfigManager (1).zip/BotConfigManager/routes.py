import logging
from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_user, login_required, logout_user, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from app import app, db, csrf
from models import User, BotConfig, ChannelConfig, MessageHistory
from forms import LoginForm, BotConfigForm, ChannelConfigForm, RegistrationForm
import bot_runner

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('config'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        # Check if username already exists
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.', 'danger')
            return render_template('register.html', form=form)
        
        # Create new user
        new_user = User(
            username=form.username.data,
            password_hash=generate_password_hash(form.password.data)
        )
        db.session.add(new_user)
        db.session.commit()
        
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('config'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('config'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/config')
@login_required
def config():
    bot_configs = BotConfig.query.filter_by(user_id_fk=current_user.id).all()
    bot_form = BotConfigForm()
    channel_form = ChannelConfigForm()
    
    return render_template('config.html', 
                          bot_configs=bot_configs, 
                          bot_form=bot_form, 
                          channel_form=channel_form)

@app.route('/api/bot_config', methods=['POST'])
@login_required
def add_bot_config():
    form = BotConfigForm()
    if form.validate_on_submit():
        new_config = BotConfig(
            token=form.token.data,
            user_id=form.user_id.data,
            duration=form.duration.data,
            webhook_url=form.webhook_url.data,
            user_id_fk=current_user.id
        )
        db.session.add(new_config)
        db.session.commit()
        flash('Bot configuration added successfully!', 'success')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"{field}: {error}", 'danger')
    
    return redirect(url_for('config'))

@app.route('/api/bot_config/<int:config_id>', methods=['PUT', 'DELETE'])
@login_required
@csrf.exempt
def manage_bot_config(config_id):
    bot_config = BotConfig.query.filter_by(id=config_id, user_id_fk=current_user.id).first_or_404()
    
    if request.method == 'PUT':
        data = request.get_json()
        bot_config.token = data.get('token', bot_config.token)
        bot_config.user_id = data.get('user_id', bot_config.user_id)
        bot_config.duration = data.get('duration', bot_config.duration)
        bot_config.webhook_url = data.get('webhook_url', bot_config.webhook_url)
        db.session.commit()
        return jsonify({'status': 'success', 'message': 'Bot configuration updated successfully'})
    
    elif request.method == 'DELETE':
        # Stop the bot if it's running
        if bot_config.is_running:
            bot_runner.stop_bot(bot_config.id)
        
        db.session.delete(bot_config)
        db.session.commit()
        return jsonify({'status': 'success', 'message': 'Bot configuration deleted successfully'})

@app.route('/api/channel_config', methods=['POST'])
@login_required
def add_channel_config():
    form = ChannelConfigForm()
    logging.info(f"Channel form data: {request.form}")
    
    if form.validate_on_submit():
        logging.info(f"Channel form validated: bot_config_id={form.bot_config_id.data}, channel_id={form.channel_id.data}")
        
        # Verify that the bot config belongs to the current user
        bot_config = BotConfig.query.filter_by(
            id=form.bot_config_id.data, 
            user_id_fk=current_user.id
        ).first_or_404()
        
        logging.info(f"Bot config found: id={bot_config.id}, user_id_fk={bot_config.user_id_fk}")
        
        new_channel = ChannelConfig(
            channel_id=form.channel_id.data,
            delay_min=form.delay_min.data,
            delay_max=form.delay_max.data,
            message_content=form.message_content.data,
            bot_config_id=bot_config.id
        )
        db.session.add(new_channel)
        db.session.commit()
        logging.info(f"Channel added with id={new_channel.id}")
        
        flash('Channel configuration added successfully!', 'success')
    else:
        logging.error(f"Channel form validation failed: {form.errors}")
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"{field}: {error}", 'danger')
    
    return redirect(url_for('config'))

@app.route('/api/channel_config/<int:channel_id>', methods=['PUT', 'DELETE'])
@login_required
@csrf.exempt
def manage_channel_config(channel_id):
    # Get the channel config and ensure it belongs to the current user's bot config
    channel = ChannelConfig.query.join(BotConfig).filter(
        ChannelConfig.id == channel_id,
        BotConfig.user_id_fk == current_user.id
    ).first_or_404()
    
    if request.method == 'PUT':
        data = request.get_json()
        channel.channel_id = data.get('channel_id', channel.channel_id)
        channel.delay_min = data.get('delay_min', channel.delay_min)
        channel.delay_max = data.get('delay_max', channel.delay_max)
        channel.message_content = data.get('message_content', channel.message_content)
        db.session.commit()
        return jsonify({'status': 'success', 'message': 'Channel configuration updated successfully'})
    
    elif request.method == 'DELETE':
        db.session.delete(channel)
        db.session.commit()
        return jsonify({'status': 'success', 'message': 'Channel configuration deleted successfully'})

@app.route('/api/bot_control/<int:config_id>/<action>', methods=['POST'])
@login_required
def control_bot(config_id, action):
    bot_config = BotConfig.query.filter_by(id=config_id, user_id_fk=current_user.id).first_or_404()
    
    if action == 'start':
        if not bot_config.is_running:
            # Check if there are channel configurations
            if len(bot_config.channels) == 0:
                return jsonify({'status': 'error', 'message': 'No channels configured for this bot'})
            
            success = bot_runner.start_bot(bot_config.id)
            if success:
                bot_config.is_running = True
                db.session.commit()
                return jsonify({'status': 'success', 'message': 'Bot started successfully'})
            else:
                return jsonify({'status': 'error', 'message': 'Failed to start bot'})
        else:
            return jsonify({'status': 'error', 'message': 'Bot is already running'})
    
    elif action == 'stop':
        if bot_config.is_running:
            success = bot_runner.stop_bot(bot_config.id)
            if success:
                bot_config.is_running = False
                db.session.commit()
                return jsonify({'status': 'success', 'message': 'Bot stopped successfully'})
            else:
                return jsonify({'status': 'error', 'message': 'Failed to stop bot'})
        else:
            return jsonify({'status': 'error', 'message': 'Bot is not running'})
    
    return jsonify({'status': 'error', 'message': 'Invalid action'})


@app.route('/api/edit_message/<int:channel_id>', methods=['POST'])
@login_required
@csrf.exempt
def edit_channel_message(channel_id):
    """Edit message content for a channel without stopping the bot"""
    # Get the channel config and ensure it belongs to the current user
    channel = ChannelConfig.query.join(BotConfig).filter(
        ChannelConfig.id == channel_id,
        BotConfig.user_id_fk == current_user.id
    ).first_or_404()
    
    data = request.get_json()
    new_message = data.get('message_content')
    
    if not new_message:
        return jsonify({'status': 'error', 'message': 'Message content is required'})
    
    # Update the message in the database
    channel.message_content = new_message
    db.session.commit()
    
    # Update the message in the running bot
    import discord_bot
    success = discord_bot.edit_channel_message(channel.id, new_message)
    
    if success:
        return jsonify({
            'status': 'success', 
            'message': 'Message updated successfully. New messages will use the updated content.'
        })
    else:
        return jsonify({
            'status': 'error', 
            'message': 'Bot update failed. Database updated, but running bot may not be using the new message.'
        })

@app.route('/config/<int:config_id>/history')
@login_required
def message_history(config_id):
    """View message history for a bot configuration"""
    bot_config = BotConfig.query.filter_by(id=config_id, user_id_fk=current_user.id).first_or_404()
    messages = MessageHistory.query.filter_by(bot_config_id=config_id).order_by(MessageHistory.sent_at.desc()).all()
    
    return render_template('message_history.html', bot_config=bot_config, messages=messages)
