import requests
import random
import time
import threading
import logging

# Global dictionary to store updated messages for channels
channel_messages = {}

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Configure requests to retry automatically
try:
    from requests.adapters import HTTPAdapter
    import urllib3
    
    # Menggunakan urllib3.Retry langsung alih-alih dari requests.packages
    retry_strategy = urllib3.Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session = requests.Session()
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    
    # Replace standard requests with the session
    def session_get(*args, **kwargs):
        return session.get(*args, **kwargs)
    
    def session_post(*args, **kwargs):
        return session.post(*args, **kwargs)
    
    # Monkey patch requests methods
    requests.get = session_get
    requests.post = session_post
    
    logging.info("Configured requests with automatic retry strategy")
except Exception as e:
    logging.warning(f"Failed to configure requests retry strategy: {e}")
    logging.warning("Will use default requests behavior without retries")

# Dictionary to track threads per token/user
active_threads = {}
# Global threads list
threads = []
# Flag to signal all threads to stop
stop_all_flag = threading.Event()
# Locks untuk mencegah pengiriman pesan secara bersamaan antar channel
message_send_lock = threading.Lock()
# Dictionary to store channel message content that can be edited without stopping the bot
channel_messages = {}

def send_message_with_delay(token_info):
    """
    Main function to start sending messages with delays across multiple channels
    
    Args:
        token_info (dict): Dictionary containing all the bot configuration
    """
    global threads
    
    # Strip whitespace from token to prevent header errors
    token = token_info["token"].strip()
    user_id = token_info["user_id"].strip()
    duration = token_info["duration"]
    webhook_url = token_info.get("webhook_url")
    bot_config_id = token_info.get('bot_config_id')
    
    logging.info(f"Starting bot with user ID: {user_id}")
    
    # Create a thread for each channel
    for channel in token_info["channels"]:
        channel_config_id = channel.get("channel_config_id")
        thread = threading.Thread(
            target=send_message_to_channel,
            args=(token, user_id, channel["channel_id"], channel["delay_range"], 
                  channel["message_content"], duration, webhook_url),
            kwargs={"channel_config_id": channel_config_id, "bot_config_id": bot_config_id}
        )
        thread.daemon = True
        thread.start()
        threads.append(thread)
        logging.info(f"Started thread for channel ID: {channel['channel_id']}, channel_config_id: {channel_config_id}")
    
    # Store threads in active_threads dictionary using bot_config_id as the key
    if bot_config_id:
        active_threads[bot_config_id] = threads
        logging.info(f"Stored threads for bot_config_id: {bot_config_id}, thread count: {len(threads)}")
    
    # Wait for all threads to complete
    for thread in threads:
        thread.join()

def send_webhook_notification(webhook_url, message_link, message_content):
    """
    Send a notification to a Discord webhook after successful message posting
    
    Args:
        webhook_url (str): The webhook URL to send notifications to
        message_link (str): Link to the posted message
        message_content (str): Content of the posted message
    """
    if not webhook_url:
        return
    
    try:
        embed = {
            "title": "Successful Post",
            "description": f"Message Link: {message_link}",
            "fields": [
                {
                    "name": "Message Content",
                    "value": message_content[:1000] + "..." if len(message_content) > 1000 else message_content
                }
            ]
        }
        
        data = {
            "embeds": [embed]
        }
        
        response = requests.post(webhook_url, json=data, headers={"Content-Type": "application/json"})
        if response.status_code == 204:
            logging.info(f"Webhook notification sent successfully for message: {message_link}")
        else:
            logging.error(f"Failed to send webhook notification: {response.text}")
    except Exception as e:
        logging.error(f"Error sending webhook notification: {str(e)}")

def send_discord_message(token, channel_id, message_data, webhook_url, channel_config_id=None, bot_config_id=None):
    """
    Send a message to a Discord channel
    
    Args:
        token (str): Discord token
        channel_id (str): Channel ID to post to
        message_data (dict): Message data to send
        webhook_url (str): Webhook URL for notifications
        channel_config_id (int, optional): Channel config ID for DB tracking
        bot_config_id (int, optional): Bot config ID for DB tracking
        
    Returns:
        bool: True if successful, False otherwise
    """
    # Strip any whitespace from token and channel_id
    token = token.strip() if token else ""
    channel_id = str(channel_id).strip() if channel_id else ""
    
    logging.info(f"Attempting to send message to channel {channel_id}")
    logging.info(f"Message data: {message_data}")
    
    # Self-bot tokens need to be prefixed differently than bot tokens
    # If token looks like a bot token (MTk...), don't prefix
    # If it looks like a user token (starts with different format), add prefix
    if token.startswith("Bot ") or token.startswith("Bearer "):
        auth_token = token
    else:
        auth_token = token  # Token sebagaimana adanya untuk self-bot
    
    header_data = {
        "content-type": "application/json",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36",
        "authorization": auth_token,
        "host": "discord.com",
        "referer": "https://discord.com/",
        "x-super-properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEwNi4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTA2LjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiIiLCJyZWZlcnJpbmdfZG9tYWluIjoiIiwicmVmZXJyZXJfY3VycmVudCI6IiIsInJlZmVycmluZ19kb21haW5fY3VycmVudCI6IiIsInJlbGVhc2VfY2hhbm5lbCI6InN0YWJsZSIsImNsaWVudF9idWlsZF9udW1iZXIiOjk5OTksImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGx9"
    }
    
    logging.info(f"Headers: {header_data}")
    
    # Mask token for logging (show only first 10 and last 5 chars)
    if len(token) > 20:
        masked_token = token[:10] + "..." + token[-5:]
    else:
        masked_token = "TOKEN_TOO_SHORT"
    
    logging.info(f"Using token: {masked_token}")

    try:
        # Try the newer v9 API endpoint first
        url = f"https://discord.com/api/v9/channels/{channel_id}/messages"
        logging.info(f"Sending request to: {url}")
        
        response = requests.post(
            url, 
            json=message_data, 
            headers=header_data
        )
        
        # Log the full response for debugging
        logging.info(f"Response status: {response.status_code}")
        logging.info(f"Response headers: {response.headers}")
        
        try:
            response_json = response.json()
            logging.info(f"Response JSON: {response_json}")
        except Exception:
            logging.info(f"Response text: {response.text}")
        
        if response.status_code == 200:
            logging.info(f"Channel ID: {channel_id} | Status: Message Sent Successfully")
            message_id = response.json()["id"]
            # Message link format seharusnya: https://discord.com/channels/guild_id/channel_id/message_id
            # Discord API tidak mengembalikan guild_id, sehingga kita perlu ekstrak dari channel_id
            # Format yang benar: https://discord.com/channels/SERVER_ID/CHANNEL_ID/MESSAGE_ID
            guild_id = channel_id.split('/')[0] if '/' in channel_id else channel_id
            message_link = f"https://discord.com/channels/{guild_id}/{channel_id}/{message_id}"
            
            # Save message to database if IDs are provided
            if channel_config_id and bot_config_id:
                try:
                    # Import here to avoid circular imports
                    from app import db, app
                    from models import MessageHistory
                    
                    # Use app context to interact with the database
                    with app.app_context():
                        new_history = MessageHistory(
                            message_id=message_id,
                            content=message_data["content"],
                            channel_name=f"Channel {channel_id}",
                            status="sent",
                            channel_config_id=channel_config_id,
                            bot_config_id=bot_config_id
                        )
                        db.session.add(new_history)
                        db.session.commit()
                        logging.info(f"Message saved to history DB with ID: {new_history.id}")
                except Exception as e:
                    logging.error(f"Failed to save message to history: {e}")
                    import traceback
                    logging.error(traceback.format_exc())
            
            send_webhook_notification(webhook_url, message_link, message_data["content"])
            return True
        elif response.status_code == 401:
            logging.error(f"Authentication failed: Discord token may be invalid or expired")
            return False
        elif response.status_code == 403:
            logging.error(f"Permission denied: Bot may not have access to this channel")
            return False
        elif response.status_code == 429:  # Rate limit error
            retry_after = response.json().get('retry_after', 60) / 1000  # Convert to seconds
            logging.warning(f"Channel ID: {channel_id} | Status: Rate limit hit. Sleeping for {retry_after} seconds.")
            time.sleep(retry_after)
            return False
        else:
            logging.error(f"Channel ID: {channel_id} | Status: Failed Response: {response.text}")
            
            # Fallback to older v6 API
            logging.info("Trying fallback to v6 API...")
            url = f"https://discord.com/api/v6/channels/{channel_id}/messages"
            logging.info(f"Sending request to: {url}")
            
            response = requests.post(
                url, 
                json=message_data, 
                headers=header_data
            )
            
            if response.status_code == 200:
                logging.info(f"Channel ID: {channel_id} | Status: Message Sent Successfully (v6 API)")
                message_id = response.json()["id"]
                # Message link format yang benar untuk v6 API juga
                guild_id = channel_id.split('/')[0] if '/' in channel_id else channel_id
                message_link = f"https://discord.com/channels/{guild_id}/{channel_id}/{message_id}"
                
                # Save message to history for v6 API calls too
                if channel_config_id and bot_config_id:
                    try:
                        # Import here to avoid circular imports
                        from app import db, app
                        from models import MessageHistory
                        
                        # Use app context to interact with the database
                        with app.app_context():
                            new_history = MessageHistory(
                                message_id=message_id,
                                content=message_data["content"],
                                channel_name=f"Channel {channel_id}",
                                status="sent (v6 API)",
                                channel_config_id=channel_config_id,
                                bot_config_id=bot_config_id
                            )
                            db.session.add(new_history)
                            db.session.commit()
                            logging.info(f"Message saved to history DB with ID: {new_history.id} (v6 API)")
                    except Exception as e:
                        logging.error(f"Failed to save message to history (v6 API): {e}")
                        import traceback
                        logging.error(traceback.format_exc())
                        
                send_webhook_notification(webhook_url, message_link, message_data["content"])
                return True
            else:
                logging.error(f"V6 API also failed - Response: {response.text}")
                return False
    
    except Exception as e:
        logging.error(f"Error sending Discord message to channel {channel_id}: {str(e)}")
        import traceback
        logging.error(traceback.format_exc())
        return False

def edit_channel_message(channel_config_id, new_message_content):
    """
    Edit the message content that will be sent by a specific channel.
    This allows changing the message without stopping the bot.
    
    Args:
        channel_config_id (int): The channel configuration ID
        new_message_content (str): The new message content to use
        
    Returns:
        bool: True if successful, False otherwise
    """
    logging.info(f"Updating message content for channel_config_id {channel_config_id}")
    
    if not channel_config_id:
        logging.error("No channel_config_id provided")
        return False
    
    # Store the new message content in the global dictionary
    global channel_messages
    channel_messages[channel_config_id] = new_message_content
    logging.info(f"Message content updated for channel {channel_config_id}: {new_message_content}")
    return True

def send_message_to_channel(token, user_id, channel_id, delay_range, message_content, duration, webhook_url, 
                       channel_config_id=None, bot_config_id=None):
    """
    Send messages to a specific channel with random delays
    
    Args:
        token (str): Discord token
        user_id (str): User ID of the bot
        channel_id (str): Channel ID to post to
        delay_range (tuple): Tuple of (min_delay, max_delay) in seconds
        message_content (str): Message content to send
        duration (int): Duration in minutes to run
        webhook_url (str): Webhook URL for notifications
        channel_config_id (int, optional): Channel config ID for DB tracking
        bot_config_id (int, optional): Bot config ID for DB tracking
    """
    # Strip whitespace from token and user_id to prevent header errors
    token = token.strip() if token else ""
    user_id = user_id.strip() if user_id else ""
    channel_id = str(channel_id).strip() if channel_id else ""
    
    start_time = time.time()
    end_time = start_time + (duration * 60)
    
    logging.info(f"Starting to send messages to channel {channel_id} with delays {delay_range}")
    logging.info(f"User ID for bot: {user_id}")
    
    # Tambahkan randomisasi delay awal untuk mencegah pengiriman bersamaan di beberapa channel
    initial_delay = random.randint(5, 15)
    logging.info(f"Adding random initial delay of {initial_delay} seconds for channel {channel_id}")
    time.sleep(initial_delay)
    
    # First, try to send a message directly without checking last messages
    # This is useful for initial testing and to ensure at least one message is sent
    first_attempt = True
    
    # Tambahkan variabel untuk tracking sudah cek stop_flag atau belum
    # Cek stop_flag setiap siklus
    check_interval = 5  # seconds
    last_check_time = time.time()
    
    while time.time() < end_time:
        # Cek stop_flag secara reguler
        current_time = time.time()
        if stop_all_flag.is_set():
            logging.info(f"Stop flag detected for channel {channel_id}, stopping message sending.")
            return
        
        try:
            should_send_message = False
            
            if first_attempt:
                # Skip message check on first attempt
                should_send_message = True
                first_attempt = False
                logging.info(f"First attempt, sending message to channel {channel_id} without checking last message...")
            else:
                # For subsequent attempts, check last message
                # Try multiple API versions
                
                # Prepare the headers for GET request with same formatted fields as POST
                if token.startswith("Bot ") or token.startswith("Bearer "):
                    auth_token = token
                else:
                    auth_token = token  # Use token as is for self-bot
                
                get_headers = {
                    "Authorization": auth_token,
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
                    "Accept": "*/*",
                    "Accept-Language": "en-US,en;q=0.5",
                    "Content-Type": "application/json",
                    "Referer": "https://discord.com/channels/@me",
                    "x-super-properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExMC4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTEwLjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiIiLCJyZWZlcnJpbmdfZG9tYWluIjoiIiwicmVmZXJyZXJfY3VycmVudCI6IiIsInJlZmVycmluZ19kb21haW5fY3VycmVudCI6IiIsInJlbGVhc2VfY2hhbm5lbCI6InN0YWJsZSIsImNsaWVudF9idWlsZF9udW1iZXIiOjk5OTksImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGx9",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-origin"
                }
                
                # First try v9 API
                logging.info(f"Checking last message in channel {channel_id} with API v9...")
                response = requests.get(
                    f"https://discord.com/api/v9/channels/{channel_id}/messages?limit=1", 
                    headers=get_headers
                )
                
                if response.status_code != 200:
                    logging.warning(f"Failed to fetch messages with v9 API, trying v6... Error: {response.text}")
                    
                    # Fallback to v6 API with the same enhanced headers
                    logging.info(f"Trying v6 API with enhanced headers for channel {channel_id}...")
                    response = requests.get(
                        f"https://discord.com/api/v6/channels/{channel_id}/messages?limit=1", 
                        headers=get_headers
                    )
                    
                if response.status_code != 200:
                    logging.error(f"Failed to fetch messages from channel {channel_id}: {response.text}")
                    if response.status_code == 401:
                        logging.error("Authentication failed. Token may be invalid or expired.")
                    elif response.status_code == 403:
                        logging.error("Permission denied. Bot may not have access to this channel.")
                    else:
                        logging.error(f"Unknown error with status code {response.status_code}")
                    
                    time.sleep(60)  # Sleep for a minute before trying again
                    continue
                
                logging.info(f"Successfully fetched messages from channel {channel_id}")
                
                try:
                    response_data = response.json()
                    logging.info(f"Channel {channel_id} messages response: {response_data}")
                    
                    if not response_data:
                        logging.warning(f"No messages found in channel {channel_id}")
                        should_send_message = True  # If no messages, proceed to send a message
                    else:
                        try:
                            last_message_author = response_data[0]['author']['id']
                            logging.info(f"Last message author ID: {last_message_author}, Bot user ID: {user_id}")
                            
                            # Always send a message based on delay, regardless of who sent the last message
                            # This ensures we keep sending based on the delay values even if our bot sent the last message
                            logging.info(f"Found last message from user ID: {last_message_author}, our bot ID: {user_id}")
                            should_send_message = True
                        except KeyError as e:
                            logging.error(f"Failed to get author ID from message: {e}")
                            logging.error(f"Message structure: {response_data[0]}")
                            # If we can't determine the author, proceed with caution (send a message)
                            should_send_message = True
                except Exception as json_error:
                    logging.error(f"Error parsing response as JSON: {json_error}")
                    logging.error(f"Raw response text: {response.text}")
                    time.sleep(30)
                    continue
            
            if should_send_message:
                logging.info(f"Sending message to channel {channel_id}")
                # Check if the message content has been updated through edit_channel_message function
                current_message = message_content
                global channel_messages
                if channel_config_id and channel_config_id in channel_messages:
                    current_message = channel_messages[channel_config_id]
                    logging.info(f"Using updated message content for channel {channel_id}: {current_message}")
                
                # Gunakan lock untuk mencegah pengiriman pesan bersamaan antar channel
                with message_send_lock:
                    # Send the message with the current message content (original or updated)
                    message_data = {"content": current_message}
                    success = send_discord_message(token, channel_id, message_data, webhook_url, 
                                                  channel_config_id=channel_config_id, 
                                                  bot_config_id=bot_config_id)
                
                if success:
                    # Random delay between messages
                    try:
                        min_delay = int(delay_range[0])
                        max_delay = int(delay_range[1])
                        if min_delay > max_delay:  # Pastikan min_delay tidak lebih besar dari max_delay
                            logging.warning(f"Min delay ({min_delay}) greater than max delay ({max_delay}), swapping values")
                            min_delay, max_delay = max_delay, min_delay
                            
                        delay = random.randint(min_delay, max_delay)
                        logging.info(f"Channel ID: {channel_id} | Status: Message sent successfully. Sleeping for {delay} seconds before next message")
                    except (ValueError, TypeError, IndexError) as e:
                        logging.error(f"Error setting delay: {str(e)}. Using default delay of 300 seconds.")
                        delay = 300  # Default delay of 5 minutes if there's an error
                    
                    # Modifikasi sleep agar memeriksa stop_flag selama delay
                    end_sleep_time = time.time() + delay
                    while time.time() < end_sleep_time:
                        if stop_all_flag.is_set():
                            logging.info(f"Stop flag detected for channel {channel_id} during sleep, stopping message sending.")
                            return
                        time.sleep(1)  # Cek stop flag setiap 1 detik
                else:
                    # If failed, wait a bit before trying again
                    logging.warning(f"Failed to send message to channel {channel_id}, waiting 60 seconds before retry")
                    
                    # Modifikasi sleep agar memeriksa stop_flag selama delay
                    end_sleep_time = time.time() + 60
                    while time.time() < end_sleep_time:
                        if stop_all_flag.is_set():
                            logging.info(f"Stop flag detected for channel {channel_id} during sleep, stopping message sending.")
                            return
                        time.sleep(1)  # Cek stop flag setiap 1 detik
            else:
                logging.info(f"Skipping sending message to channel {channel_id}, checking again soon")
                
                # Modifikasi sleep agar memeriksa stop_flag selama delay
                end_sleep_time = time.time() + 30
                while time.time() < end_sleep_time:
                    if stop_all_flag.is_set():
                        logging.info(f"Stop flag detected for channel {channel_id} during sleep, stopping message sending.")
                        return
                    time.sleep(1)  # Cek stop flag setiap 1 detik
                
        except Exception as e:
            logging.error(f"Error in channel {channel_id}: {str(e)}")
            import traceback
            logging.error(traceback.format_exc())
            
            # Modifikasi sleep agar memeriksa stop_flag selama delay
            end_sleep_time = time.time() + 60
            while time.time() < end_sleep_time:
                if stop_all_flag.is_set():
                    logging.info(f"Stop flag detected for channel {channel_id} during error sleep, stopping message sending.")
                    return
                time.sleep(1)  # Cek stop flag setiap 1 detik
    
    logging.info(f"Channel ID: {channel_id} | Status: Duration expired. Stopping message sending.")
