from app import db
from flask_login import UserMixin
from datetime import datetime

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Define relationship with BotConfig
    bot_configs = db.relationship('BotConfig', backref='user', lazy=True, cascade="all, delete-orphan")

class BotConfig(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    token = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.String(30), nullable=False)
    duration = db.Column(db.Integer, default=41760)  # Default 41760 minutes (around 29 days)
    webhook_url = db.Column(db.String(200))
    is_running = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign key to User
    user_id_fk = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Define relationship with ChannelConfig
    channels = db.relationship('ChannelConfig', backref='bot_config', lazy=True, cascade="all, delete-orphan")
    
    # Define relationship with MessageHistory
    messages = db.relationship('MessageHistory', backref='bot', lazy=True, cascade="all, delete-orphan")

class ChannelConfig(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    channel_id = db.Column(db.String(30), nullable=False)
    delay_min = db.Column(db.Integer, default=3600)  # Default 1 hour
    delay_max = db.Column(db.Integer, default=7200)  # Default 2 hours
    message_content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign key to BotConfig
    bot_config_id = db.Column(db.Integer, db.ForeignKey('bot_config.id'), nullable=False)
    
    # Relationship to message history
    message_history = db.relationship('MessageHistory', backref='channel_config', lazy=True, cascade="all, delete-orphan")


class MessageHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    message_id = db.Column(db.String(30), nullable=True)  # Discord message ID
    content = db.Column(db.Text, nullable=False)
    sent_at = db.Column(db.DateTime, default=datetime.utcnow)
    channel_name = db.Column(db.String(100))  # Optional friendly name
    status = db.Column(db.String(20), default="sent")  # sent, failed, etc.
    
    # Foreign keys
    channel_config_id = db.Column(db.Integer, db.ForeignKey('channel_config.id'), nullable=False)
    bot_config_id = db.Column(db.Integer, db.ForeignKey('bot_config.id'), nullable=False)
