document.addEventListener('DOMContentLoaded', function() {
    // Get CSRF token from form or meta tag
    const csrfFormInput = document.querySelector('#csrf-form input[name="csrf_token"]');
    const csrfToken = csrfFormInput ? csrfFormInput.value : document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    
    // Helper function to include CSRF token in fetch requests
    function fetchWithCSRF(url, options = {}) {
        // Create default headers if none exist
        if (!options.headers) {
            options.headers = {};
        }
        
        // Add CSRF token to headers
        options.headers['X-CSRFToken'] = csrfToken;
        
        // If method is POST, PUT, PATCH, or DELETE and no Content-Type is set
        // and the body is not FormData, append CSRF token to URL as query param
        if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(options.method) && 
            (!options.headers['Content-Type'] || options.headers['Content-Type'] === 'application/json')) {
            
            // Append CSRF token as query parameter if URL doesn't already have it
            const separator = url.includes('?') ? '&' : '?';
            url = `${url}${separator}csrf_token=${encodeURIComponent(csrfToken)}`;
        }
        
        // Return the fetch call
        return fetch(url, options);
    }
    // Toggle password visibility for token fields
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', function() {
            const passwordField = this.previousElementSibling;
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
            
            // Toggle eye icon
            const icon = this.querySelector('i');
            if (type === 'password') {
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            } else {
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            }
        });
    });

    // Add Channel button functionality
    document.querySelectorAll('.add-channel-btn').forEach(button => {
        button.addEventListener('click', function() {
            const configId = this.getAttribute('data-config-id');
            document.getElementById('channel-bot-config-id').value = configId;
            const modal = new bootstrap.Modal(document.getElementById('addChannelModal'));
            modal.show();
        });
    });

    // Start Bot button functionality
    document.querySelectorAll('.start-bot-btn').forEach(button => {
        button.addEventListener('click', function() {
            const configId = this.getAttribute('data-config-id');
            startBot(configId);
        });
    });

    // Stop Bot button functionality
    document.querySelectorAll('.stop-bot-btn').forEach(button => {
        button.addEventListener('click', function() {
            const configId = this.getAttribute('data-config-id');
            stopBot(configId);
        });
    });

    // Edit Bot button functionality
    document.querySelectorAll('.edit-bot-btn').forEach(button => {
        button.addEventListener('click', function() {
            const configId = this.getAttribute('data-config-id');
            const row = document.querySelector(`tr[data-config-id="${configId}"]`);
            
            // Get values from the row
            const userId = row.cells[0].textContent.trim();
            const token = row.querySelector('.token-field').value;
            const duration = row.cells[2].textContent.trim();
            const webhookUrl = row.cells[3].querySelector('small') ? 
                row.cells[3].querySelector('small').textContent.trim() : '';
            
            // Set values in the modal
            document.getElementById('edit-token').value = token;
            document.getElementById('edit-user-id').value = userId;
            document.getElementById('edit-duration').value = duration;
            document.getElementById('edit-webhook-url').value = webhookUrl;
            
            // Set data attribute for the save button
            document.getElementById('save-bot-changes').setAttribute('data-config-id', configId);
            
            // Show the modal
            const modal = new bootstrap.Modal(document.getElementById('editBotModal'));
            modal.show();
        });
    });

    // Save Bot Changes button functionality
    document.getElementById('save-bot-changes').addEventListener('click', function() {
        const configId = this.getAttribute('data-config-id');
        const token = document.getElementById('edit-token').value;
        const userId = document.getElementById('edit-user-id').value;
        const duration = document.getElementById('edit-duration').value;
        const webhookUrl = document.getElementById('edit-webhook-url').value;
        
        updateBotConfig(configId, {
            token: token,
            user_id: userId,
            duration: duration,
            webhook_url: webhookUrl
        });
    });

    // Delete Bot button functionality
    document.querySelectorAll('.delete-bot-btn').forEach(button => {
        button.addEventListener('click', function() {
            const configId = this.getAttribute('data-config-id');
            showConfirmation(
                'Are you sure you want to delete this bot configuration? This action cannot be undone.',
                function() { deleteBotConfig(configId); }
            );
        });
    });

    // Edit Channel button functionality
    document.querySelectorAll('.edit-channel-btn').forEach(button => {
        button.addEventListener('click', function() {
            const channelId = this.getAttribute('data-channel-id');
            const row = document.querySelector(`tr[data-channel-id="${channelId}"]`);
            
            // Get values from the row
            const channelDiscordId = row.cells[0].textContent.trim();
            const delayRange = row.cells[1].textContent.trim().split(' - ');
            const delayMin = delayRange[0];
            const delayMax = delayRange[1];
            const messageContent = row.querySelector('textarea').value;
            
            // Set values in the modal
            document.getElementById('edit-channel-id').value = channelDiscordId;
            document.getElementById('edit-delay-min').value = delayMin;
            document.getElementById('edit-delay-max').value = delayMax;
            document.getElementById('edit-message-content').value = messageContent;
            
            // Set data attribute for the save button
            document.getElementById('save-channel-changes').setAttribute('data-channel-id', channelId);
            
            // Show the modal
            const modal = new bootstrap.Modal(document.getElementById('editChannelModal'));
            modal.show();
        });
    });
    
    // Edit Live Message button functionality - untuk mengedit pesan tanpa menghentikan bot
    document.querySelectorAll('.edit-live-message-btn').forEach(button => {
        button.addEventListener('click', function() {
            const channelId = this.getAttribute('data-channel-id');
            const row = document.querySelector(`tr[data-channel-id="${channelId}"]`);
            const messageContent = row.querySelector('textarea').value;
            
            // Set values in the modal
            document.getElementById('edit-live-message-content').value = messageContent;
            
            // Set data attribute for the save button
            document.getElementById('save-live-message').setAttribute('data-channel-id', channelId);
            
            // Show the modal
            const modal = new bootstrap.Modal(document.getElementById('editLiveMessageModal'));
            modal.show();
        });
    });

    // Save Channel Changes button functionality
    document.getElementById('save-channel-changes').addEventListener('click', function() {
        const channelId = this.getAttribute('data-channel-id');
        const channelDiscordId = document.getElementById('edit-channel-id').value;
        const delayMin = document.getElementById('edit-delay-min').value;
        const delayMax = document.getElementById('edit-delay-max').value;
        const messageContent = document.getElementById('edit-message-content').value;
        
        updateChannelConfig(channelId, {
            channel_id: channelDiscordId,
            delay_min: delayMin,
            delay_max: delayMax,
            message_content: messageContent
        });
    });

    // Delete Channel button functionality
    document.querySelectorAll('.delete-channel-btn').forEach(button => {
        button.addEventListener('click', function() {
            const channelId = this.getAttribute('data-channel-id');
            showConfirmation(
                'Are you sure you want to delete this channel configuration? This action cannot be undone.',
                function() { deleteChannelConfig(channelId); }
            );
        });
    });

    // Save Live Message button functionality
    document.getElementById('save-live-message') && document.getElementById('save-live-message').addEventListener('click', function() {
        const channelId = this.getAttribute('data-channel-id');
        const messageContent = document.getElementById('edit-live-message-content').value;
        
        editLiveMessage(channelId, messageContent);
    });
    
    // Function to edit message for a running bot
    function editLiveMessage(channelId, messageContent) {
        fetchWithCSRF(`/api/edit_message/${channelId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message_content: messageContent
            })
        })
        .then(response => response.json())
        .then(result => {
            if (result.status === 'success') {
                // Update UI
                const row = document.querySelector(`tr[data-channel-id="${channelId}"]`);
                row.querySelector('textarea').value = messageContent;
                
                // Close the modal
                bootstrap.Modal.getInstance(document.getElementById('editLiveMessageModal')).hide();
                
                showToast('Success', result.message);
            } else {
                showToast('Error', result.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error updating live message:', error);
            showToast('Error', 'Failed to update message. Please try again.', 'danger');
        });
    }
    
    // Function to show confirmation modal
    function showConfirmation(message, callback) {
        const modal = new bootstrap.Modal(document.getElementById('confirmationModal'));
        document.getElementById('confirmation-message').textContent = message;
        
        // Remove previous event listener if exists
        const confirmButton = document.getElementById('confirm-action');
        const newConfirmButton = confirmButton.cloneNode(true);
        confirmButton.parentNode.replaceChild(newConfirmButton, confirmButton);
        
        // Add new event listener
        newConfirmButton.addEventListener('click', function() {
            modal.hide();
            callback();
        });
        
        modal.show();
    }

    // Function to start a bot
    function startBot(configId) {
        fetchWithCSRF(`/api/bot_control/${configId}/start`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Update UI
                const row = document.querySelector(`tr[data-config-id="${configId}"]`);
                const statusBadge = row.querySelector('.badge');
                statusBadge.classList.remove('bg-danger');
                statusBadge.classList.add('bg-success');
                statusBadge.textContent = 'Running';
                
                // Update buttons
                row.querySelector('.start-bot-btn').disabled = true;
                row.querySelector('.stop-bot-btn').disabled = false;
                
                showToast('Success', data.message);
            } else {
                showToast('Error', data.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error starting bot:', error);
            showToast('Error', 'Failed to start bot. Please try again.', 'danger');
        });
    }

    // Function to stop a bot
    function stopBot(configId) {
        fetchWithCSRF(`/api/bot_control/${configId}/stop`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Update UI
                const row = document.querySelector(`tr[data-config-id="${configId}"]`);
                const statusBadge = row.querySelector('.badge');
                statusBadge.classList.remove('bg-success');
                statusBadge.classList.add('bg-danger');
                statusBadge.textContent = 'Stopped';
                
                // Update buttons
                row.querySelector('.start-bot-btn').disabled = false;
                row.querySelector('.stop-bot-btn').disabled = true;
                
                showToast('Success', data.message);
            } else {
                showToast('Error', data.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error stopping bot:', error);
            showToast('Error', 'Failed to stop bot. Please try again.', 'danger');
        });
    }

    // Function to update bot configuration
    function updateBotConfig(configId, data) {
        fetchWithCSRF(`/api/bot_config/${configId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(result => {
            if (result.status === 'success') {
                // Update UI
                const row = document.querySelector(`tr[data-config-id="${configId}"]`);
                row.cells[0].textContent = data.user_id;
                row.querySelector('.token-field').value = data.token;
                row.cells[2].textContent = data.duration;
                
                if (data.webhook_url) {
                    if (row.cells[3].querySelector('small')) {
                        row.cells[3].querySelector('small').textContent = data.webhook_url.length > 30 ? 
                            data.webhook_url.substring(0, 30) + '...' : data.webhook_url;
                    } else {
                        row.cells[3].innerHTML = `<small>${data.webhook_url.length > 30 ? data.webhook_url.substring(0, 30) + '...' : data.webhook_url}</small>`;
                    }
                } else {
                    row.cells[3].innerHTML = '<span class="text-muted">None</span>';
                }
                
                // Close the modal
                bootstrap.Modal.getInstance(document.getElementById('editBotModal')).hide();
                
                showToast('Success', result.message);
            } else {
                showToast('Error', result.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error updating bot config:', error);
            showToast('Error', 'Failed to update bot configuration. Please try again.', 'danger');
        });
    }

    // Function to delete bot configuration
    function deleteBotConfig(configId) {
        fetchWithCSRF(`/api/bot_config/${configId}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Remove from UI
                const row = document.querySelector(`tr[data-config-id="${configId}"]`);
                const channelRow = document.querySelector(`tr.channel-details-row[data-parent-id="${configId}"]`);
                
                if (row) row.remove();
                if (channelRow) channelRow.remove();
                
                showToast('Success', data.message);
            } else {
                showToast('Error', data.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error deleting bot config:', error);
            showToast('Error', 'Failed to delete bot configuration. Please try again.', 'danger');
        });
    }

    // Function to update channel configuration
    function updateChannelConfig(channelId, data) {
        fetchWithCSRF(`/api/channel_config/${channelId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(result => {
            if (result.status === 'success') {
                // Update UI
                const row = document.querySelector(`tr[data-channel-id="${channelId}"]`);
                row.cells[0].textContent = data.channel_id;
                row.cells[1].textContent = `${data.delay_min} - ${data.delay_max}`;
                row.querySelector('textarea').value = data.message_content;
                
                // Close the modal
                bootstrap.Modal.getInstance(document.getElementById('editChannelModal')).hide();
                
                showToast('Success', result.message);
            } else {
                showToast('Error', result.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error updating channel config:', error);
            showToast('Error', 'Failed to update channel configuration. Please try again.', 'danger');
        });
    }

    // Function to delete channel configuration
    function deleteChannelConfig(channelId) {
        fetchWithCSRF(`/api/channel_config/${channelId}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Remove from UI
                const row = document.querySelector(`tr[data-channel-id="${channelId}"]`);
                if (row) row.remove();
                
                showToast('Success', data.message);
            } else {
                showToast('Error', data.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error deleting channel config:', error);
            showToast('Error', 'Failed to delete channel configuration. Please try again.', 'danger');
        });
    }

    // Toast notification function
    function showToast(title, message, type = 'success') {
        // Create toast container if not exists
        let toastContainer = document.querySelector('.toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
            document.body.appendChild(toastContainer);
        }
        
        // Create toast element
        const toastEl = document.createElement('div');
        toastEl.className = `toast align-items-center text-white bg-${type} border-0`;
        toastEl.setAttribute('role', 'alert');
        toastEl.setAttribute('aria-live', 'assertive');
        toastEl.setAttribute('aria-atomic', 'true');
        
        // Toast content
        toastEl.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    <strong>${title}:</strong> ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        
        // Add to container
        toastContainer.appendChild(toastEl);
        
        // Initialize and show toast
        const toast = new bootstrap.Toast(toastEl, { autohide: true, delay: 5000 });
        toast.show();
        
        // Remove from DOM after hidden
        toastEl.addEventListener('hidden.bs.toast', () => {
            toastEl.remove();
        });
    }
});
