from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, IntegerField, TextAreaField, HiddenField
from wtforms.validators import DataRequired, Length, Optional, URL, Email, EqualTo

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')
    
class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password', message='Passwords must match')])
    submit = SubmitField('Register')

class BotConfigForm(FlaskForm):
    token = StringField('Discord Token', validators=[DataRequired(), Length(min=50, max=100)])
    user_id = StringField('User ID', validators=[DataRequired(), Length(min=10, max=30)])
    duration = IntegerField('Duration (minutes)', validators=[DataRequired()], default=41760)
    webhook_url = StringField('Webhook URL', validators=[Optional(), URL()])
    submit = SubmitField('Save Configuration')

class ChannelConfigForm(FlaskForm):
    bot_config_id = HiddenField('Bot Config ID', validators=[DataRequired()])
    channel_id = StringField('Channel ID', validators=[DataRequired(), Length(min=10, max=30)])
    delay_min = IntegerField('Minimum Delay (seconds)', validators=[DataRequired()], default=3600)
    delay_max = IntegerField('Maximum Delay (seconds)', validators=[DataRequired()], default=7200)
    message_content = TextAreaField('Message Content', validators=[DataRequired()])
    submit = SubmitField('Save Channel')
